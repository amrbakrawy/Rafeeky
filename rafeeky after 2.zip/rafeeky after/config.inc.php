
<html>
<body>
<?php

$cfg['lang'] = 'en_GB';
$cfg['Console']['Mode'] = 'collapse';

?>
</body>
</html>

