
<html>
<body>
	<?php
// Database credentials
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$database = "rafeekydb";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set headers to allow cross-origin resource sharing (CORS)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Check the HTTP method of the request
$method = $_SERVER['REQUEST_METHOD'];

// Define API endpoints
switch ($method) {
    case 'GET':
        // Handle GET requests
        $sql = "SELECT * FROM Pet";
        $result = $conn->query($sql);
        $data = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
        }
        echo json_encode($data);
        break;

    case 'POST':
        // Handle POST requests
        $data = json_decode(file_get_contents('php://input'), true);
        $pet_name = $data['pet_name'];
        $pet_age = $data['pet_age'];
        $pet_type = $data['pet_type'];
        // Add validation for other fields as needed
        $sql = "INSERT INTO Pet (Pet_name, Pet_age, Pet_type) VALUES ('$pet_name', '$pet_age', '$pet_type')";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "Pet record inserted successfully"]);
        } else {
            echo json_encode(["error" => $conn->error]);
        }
        break;

    case 'PUT':
        // Handle PUT requests
        parse_str(file_get_contents("php://input"), $data);
        $pet_id = $data['pet_id'];
        $pet_name = $data['pet_name'];
        // Add validation for other fields as needed
        $sql = "UPDATE Pet SET Pet_name='$pet_name' WHERE Pet_ID='$pet_id'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "Pet record updated successfully"]);
        } else {
            echo json_encode(["error" => $conn->error]);
        }
        break;

    case 'DELETE':
        // Handle DELETE requests
        parse_str(file_get_contents("php://input"), $data);
        $pet_id = $data['pet_id'];
        $sql = "DELETE FROM Pet WHERE Pet_ID='$pet_id'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "Pet record deleted successfully"]);
        } else {
            echo json_encode(["error" => $conn->error]);
        }
        break;

    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(["error" => "Method not allowed"]);
        break;
}

// Close connection
$conn->close();
?>

</body>
</html>

