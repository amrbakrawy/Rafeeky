<html>
    <body>
        
        <?php
            $fname = $_GET["fname"];
            $uname = $_GET["uname"];
            $gender = $_GET["gender"];
            $dob = $_GET["dob"];
            $address = $_GET["address"];
            $email = $_GET["email"];
            $phone = $_GET["numb"];
            $passwordd = $_GET["passw"];
            $confirm = $_GET["conf"];
            $conn = mysqli_connect("localhost", "root", "", "rafeeky");
             $stmt="Insert into`user` (`name`,`DOB`,`username`,`password`,`email`,`Phone number`) values('$fname','$dob', '$uname','$passwordd','$email','$phone')";  
            $result = mysqli_query($conn,$stmt);
            if ($result == FALSE)
            echo "Error. $uname sign up was not added";
           else
               echo "$uname sign up was successfully added";
        ?>
    </body>
</html>

