
<?php 
// Frontend JavaScript code


fetch('backend-script.php', {

  method: 'POST', // Or 'GET', depending on your needs
  body: JSON.stringify({ /* Data to send to the backend */ }),
  headers: 
  {
    'Content-Type': 'application/json'
  }
})
.then(response => response.json())
.then(data => {
  

  // Handle the response from the backend

})
.catch(error => {
  
  // Handle any errors that occur during the request

});

    ?>