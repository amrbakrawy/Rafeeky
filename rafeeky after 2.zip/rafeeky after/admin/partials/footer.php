    <!-- Footer Section Starts -->
    <div class="footer">
        <div class="wrapper text-center">
            <p>All rights reserved. Designed By <a href="#">MASPJ</a></p>
        </div>
    </div>
    <!-- Footer Section Ends -->
    
 </body>
 </html>