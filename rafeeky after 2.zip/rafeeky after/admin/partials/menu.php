<!-- 
    writer: us
 -->
<?php
include('../config/constants.php');
include('login-check.php');
?>
 <!-- <?php
  print("Hello World");
  ?> -->


 
  <!DOCTYPE html>
  <html lang="en">
  <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Pet Adaptation Website - Home Page</title>
     <link rel="stylesheet" href="../css/admin.css">
     <link rel="icon" href="../images/favicon.png">
  </head>
  <body>
 
     <!-- Menu Section Starts -->
     <div class="menu">
         <div class="wrapper text-center">
             <ul>
                 <li> <a href="index.php">Home</a></li>
                 <li> <a href="manage-admin.php">Admin</a></li>
                 <li><a href="manage-category.php">Category</a></li>
                 <li><a href="manage-pet.php">Pet</a></li>
                 <li><a href="manage-adopt.php">Adopt</a></li>
                 <li><a href="helpline.php">Helpline</a></li>
                 <li><a href="logout.php">Logout</a></li>
             </ul>
         </div>
     </div>
     <!-- Menu Section Ends -->
 
     <!-- For Background Image -->
     <section class="pet-background">
         <br>
         <br>
         <br>
     </section>
     <!-- For Background Image -->
     
     