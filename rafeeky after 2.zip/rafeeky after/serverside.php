<html>
    <body>
        
    <?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rafeekydb";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to add a new pet owner
function addPetOwner($owner_name, $phone_num, $gender, $email, $pet_id) {
    global $conn;
    $sql = "INSERT INTO Pet_Owner (Owner_name, Phone_num, Gender, Email, Pet_ID) 
            VALUES ('$owner_name', '$phone_num', '$gender', '$email', '$pet_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New pet owner record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a pet owner
function deletePetOwner($owner_id) {
    global $conn;
    $sql = "DELETE FROM Pet_Owner WHERE Owner_ID='$owner_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Pet owner record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update pet owner information
function updatePetOwner($owner_id, $owner_name, $phone_num, $gender, $email, $pet_id) {
    global $conn;
    $sql = "UPDATE Pet_Owner SET Owner_name='$owner_name', Phone_num='$phone_num', Gender='$gender', Email='$email', Pet_ID='$pet_id' WHERE Owner_ID='$owner_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Pet owner record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to add a new pet
function addPet($pet_name, $pet_age, $pet_type, $pet_vaccination, $vaccination_date, $owner_id) {
    global $conn;
    $sql = "INSERT INTO Pet (Pet_name, Pet_age, Pet_type, Pet_vaccination, Vaccination_date, Owner_ID) 
            VALUES ('$pet_name', '$pet_age', '$pet_type', '$pet_vaccination', '$vaccination_date', '$owner_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New pet record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a pet
function deletePet($pet_id) {
    global $conn;
    $sql = "DELETE FROM Pet WHERE Pet_ID='$pet_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Pet record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update pet information
function updatePet($pet_id, $pet_name, $pet_age, $pet_type, $pet_vaccination, $vaccination_date, $owner_id) {
    global $conn;
    $sql = "UPDATE Pet SET Pet_name='$pet_name', Pet_age='$pet_age', Pet_type='$pet_type', Pet_vaccination='$pet_vaccination', Vaccination_date='$vaccination_date', Owner_ID='$owner_id' WHERE Pet_ID='$pet_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Pet record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to add a new donation
function addDonation($donation_amount, $donation_destination, $user_id) {
    global $conn;
    $sql = "INSERT INTO Donation (Donation_amount, Donation_destination, User_ID) 
            VALUES ('$donation_amount', '$donation_destination', '$user_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New donation record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a donation
function deleteDonation($donation_num) {
    global $conn;
    $sql = "DELETE FROM Donation WHERE Donation_num='$donation_num'";
    if ($conn->query($sql) === TRUE) {
        echo "Donation record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update donation information
function updateDonation($donation_num, $donation_amount, $donation_destination, $user_id) {
    global $conn;
    $sql = "UPDATE Donation SET Donation_amount='$donation_amount', Donation_destination='$donation_destination', User_ID='$user_id' WHERE Donation_num='$donation_num'";
    if ($conn->query($sql) === TRUE) {
        echo "Donation record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to add a new user
function addUser($user_name, $phone_num, $gender, $email) {
    global $conn;
    $sql = "INSERT INTO User (User_name, Phone_num, Gender, Email) 
            VALUES ('$user_name', '$phone_num', '$gender', '$email')";
    if ($conn->query($sql) === TRUE) {
        echo "New user record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a user
function deleteUser($user_id) {
    global $conn;
    $sql = "DELETE FROM User WHERE User_ID='$user_id'";
    if ($conn->query($sql) === TRUE) {
        echo "User record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update user information
function updateUser($user_id, $user_name, $phone_num, $gender, $email) {
    global $conn;
    $sql = "UPDATE User SET User_name='$user_name', Phone_num='$phone_num', Gender='$gender', Email='$email' WHERE User_ID='$user_id'";
    if ($conn->query($sql) === TRUE) {
        echo "User record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

           // Function to add a new rescue
function addRescue($rescue_description, $rescue_status, $rescue_location, $shelter_id, $vet_id) {
    global $conn;
    $sql = "INSERT INTO Rescue (Rescue_description, Rescue_status, Rescue_location, Shelter_ID, Vet_ID) 
            VALUES ('$rescue_description', '$rescue_status', '$rescue_location', '$shelter_id', '$vet_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New rescue record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a rescue
function deleteRescue($rescue_num) {
    global $conn;
    $sql = "DELETE FROM Rescue WHERE Rescue_num='$rescue_num'";
    if ($conn->query($sql) === TRUE) {
        echo "Rescue record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update rescue information
function updateRescue($rescue_num, $rescue_description, $rescue_status, $rescue_location, $shelter_id, $vet_id) {
    global $conn;
    $sql = "UPDATE Rescue SET Rescue_description='$rescue_description', Rescue_status='$rescue_status', Rescue_location='$rescue_location', Shelter_ID='$shelter_id', Vet_ID='$vet_id' WHERE Rescue_num='$rescue_num'";
    if ($conn->query($sql) === TRUE) {
        echo "Rescue record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to add a new vet
function addVet($vet_name, $vet_num, $vet_address) {
    global $conn;
    $sql = "INSERT INTO Vet (Vet_name, Vet_num, Vet_address) 
            VALUES ('$vet_name', '$vet_num', '$vet_address')";
    if ($conn->query($sql) === TRUE) {
        echo "New vet record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a vet
function deleteVet($vet_id) {
    global $conn;
    $sql = "DELETE FROM Vet WHERE Vet_ID='$vet_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Vet record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update vet information
function updateVet($vet_id, $vet_name, $vet_num, $vet_address) {
    global $conn;
    $sql = "UPDATE Vet SET Vet_name='$vet_name', Vet_num='$vet_num', Vet_address='$vet_address' WHERE Vet_ID='$vet_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Vet record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to add a new payment
function addPayment($payment_amount, $card_details, $payment_status, $product_bought, $user_id) {
    global $conn;
    $sql = "INSERT INTO Payment (Payment_amount, Card_details, Payment_status, Product_bought, User_ID) 
            VALUES ('$payment_amount', '$card_details', '$payment_status', '$product_bought', '$user_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New payment record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a payment
function deletePayment($payment_id) {
    global $conn;
    $sql = "DELETE FROM Payment WHERE Payment_ID='$payment_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Payment record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update payment information
function updatePayment($payment_id, $payment_amount, $card_details, $payment_status, $product_bought, $user_id) {
    global $conn;
    $sql = "UPDATE Payment SET Payment_amount='$payment_amount', Card_details='$card_details', Payment_status='$payment_status', Product_bought='$product_bought', User_ID='$user_id' WHERE Payment_ID='$payment_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Payment record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to add a new shelter
function addShelter($shelter_name, $phone_num, $address) {
    global $conn;
    $sql = "INSERT INTO Shelter (Shelter_name, Phone_num, Address) 
            VALUES ('$shelter_name', '$phone_num', '$address')";
    if ($conn->query($sql) === TRUE) {
        echo "New shelter record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to delete a shelter
function deleteShelter($shelter_id) {
    global $conn;
    $sql = "DELETE FROM Shelter WHERE Shelter_ID='$shelter_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Shelter record deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to update shelter information
function updateShelter($shelter_id, $shelter_name, $phone_num, $address) {
    global $conn;
    $sql = "UPDATE Shelter SET Shelter_name='$shelter_name', Phone_num='$phone_num', Address='$address' WHERE Shelter_ID='$shelter_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Shelter record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close database connection
$conn->close();
?>
    </body>
</html>

