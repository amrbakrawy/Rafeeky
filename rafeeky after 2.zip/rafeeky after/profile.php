<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $mobileNumber = $_POST['mobileNumber'];
    $addressLine1 = $_POST['addressLine1'];
    $postcode = $_POST['postcode'];
    $state = $_POST['state'];
    $area = $_POST['area'];
    $email = $_POST['email'];
    $country = $_POST['country'];
    $stateRegion = $_POST['stateRegion'];
    $ownedPets = $_POST['ownedPets'];
    $additionalDetails = $_POST['additionalDetails'];

    // Check if a file was uploaded
    if(isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] === UPLOAD_ERR_OK) {
        // Specify the directory where uploaded files will be stored
        $uploadDirectory = 'uploads/';

        // Generate a unique filename to avoid overwriting existing files
        $fileName = uniqid('profile_') . '_' . $_FILES['profilePicture']['name'];

        // Move the uploaded file to the specified directory
        $filePath = $uploadDirectory . $fileName;
        if(move_uploaded_file($_FILES['profilePicture']['tmp_name'], $filePath)) {
            echo "<h2>Profile picture uploaded successfully!</h2>";
        } else {
            echo "<h2>Error uploading profile picture.</h2>";
        }
    } else {
        echo "<h2>No profile picture uploaded.</h2>";
    }

    // Create an array to store the profile data
    $profileData = [
        'First Name' => $firstName,
        'Last Name' => $lastName,
        'Mobile Number' => $mobileNumber,
        'Address Line 1' => $addressLine1,
        'Postcode' => $postcode,
        'State' => $state,
        'Area' => $area,
        'Email' => $email,
        'Country' => $country,
        'State/Region' => $stateRegion,
        'Owned Pets' => $ownedPets,
        'Additional Details' => $additionalDetails,
        'Profile Picture' => $fileName  // Store the filename in the profile data
    ];

    // Convert the array to JSON format
    $jsonData = json_encode($profileData);

    // Define the file path where the data will be saved
    $filePath = 'profile_data.json';

    // Write the JSON data to the file
    file_put_contents($filePath, $jsonData);

    // Display success message
    echo "<h2>Profile data saved successfully!</h2>";
} else {
    // Redirect back to the form if accessed directly
    header("profile.html");
    exit;
}
?>
