

<html>
<body>
<?php
$conn = mysqli_connect("localhost", "root", "", "rafeekydb");
if($conn==TRUE)
echo "Successfully connected to the database.";   
else 
echo "Failed to connect to the database!";
?>
</body>
</html>


